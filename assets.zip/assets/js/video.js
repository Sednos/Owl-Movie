	var video = document.getElementById("monplayer");
	
	video.removeAttribute("controls");
	//video.style.display='none';
	
	
	video.addEventListener('ended',function()
	{
	},false);
	
	window.onload=function(){
	//video.play(); 
	}
	

		
