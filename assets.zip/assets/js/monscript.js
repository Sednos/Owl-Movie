$(document).ready(function() {
  $('.drawer').drawer();
});